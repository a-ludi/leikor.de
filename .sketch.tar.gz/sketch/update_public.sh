#!/bin/bash

rm -rf ~/public/public-share/leikor.de
cp -r ~/projects/leikor.de/view_sketch ~/public/public-share/leikor.de
rm -f ~/public/public-share/leikor.de/update_public.sh
